﻿using System;
using System.Threading;
using OpenQA.Selenium;
namespace adactin_pom
{
    public class SelectHotelHelper : BaseClass
    {
        By hotel = By.Id("radiobutton_1");
        By contunueWithSelectedHotel = By.Id("continue");

        public void selectHotel()
        {
            driver.FindElement(hotel).Click();
            driver.FindElement(contunueWithSelectedHotel).Click();
            //Thread.Sleep(5000);
        }
       
    }
}
