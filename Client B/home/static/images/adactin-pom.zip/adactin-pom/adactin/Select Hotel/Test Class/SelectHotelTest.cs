﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
namespace adactin_pom.adactin.SelectHotel.TestClass
{
    [TestFixture]
    public class SelectHotelTest
    {
        LoginHelper loginHelper = new LoginHelper();
        SearchHelper searchHelper = new SearchHelper();
        SelectHotelHelper selectHotelHelper = new SelectHotelHelper();

        [SetUp]
        public void TestInit()
        {
            selectHotelHelper.Initialization();
        }

        [Test]
        public void SearchhotelSuccessfully()
        {
            selectHotelHelper.OpenBrowser();
            loginHelper.Login("kamran90", "Karachi123");
            searchHelper.Search();
            selectHotelHelper.selectHotel();
            string msg = BaseClass.driver.FindElement(By.CssSelector("table.content:nth-child(2) form:nth-child(1) table.login tbody:nth-child(1) tr:nth-child(2) > td.login_title")).Text;
            Assert.IsTrue(msg.ToLower().Contains("book a hotel"));
        }
        [TearDown]
        public void TestDispose()
        {
            selectHotelHelper.Dispose();
        }
    }
}
