﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
namespace adactin_pom
{
    public class BookHotelTest
    {
        [TestFixture]
        public class SelectHotelTest
        {
            LoginHelper loginHelper = new LoginHelper();
            SearchHelper searchHelper = new SearchHelper();
            SelectHotelHelper selectHotelHelper = new SelectHotelHelper();
            BookHotelHelper bookHotelHelper = new BookHotelHelper();

            [SetUp]
            public void TestInit()
            {
                bookHotelHelper.Initialization();
            }

            [Test]
            public void SearchhotelSuccessfully()
            {
                selectHotelHelper.OpenBrowser();
                loginHelper.Login("kamran90", "Karachi123");
                searchHelper.Search();
                selectHotelHelper.selectHotel();
                bookHotelHelper.bookHotel();
                var wait = new WebDriverWait(BaseClass.driver, TimeSpan.FromSeconds(20));
                var msg = wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector("table.content:nth-child(2) form:nth-child(1) table.login tbody:nth-child(1) tr:nth-child(1) > td.login_title")));
                Assert.IsTrue(msg.Text.ToLower().Contains("booking confirmation"));
            }
            [TearDown]
            public void TestDispose()
            {
                bookHotelHelper.Dispose();
            }
        }
    }
}
