﻿using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace adactin_pom
{
    public class BookHotelHelper : BaseClass
    {
        By firstName = By.Id("first_name");
        By lastName = By.Id("last_name");
        By address = By.Id("address");
        By ccNum = By.Id("cc_num");
        By ccType = By.Id("cc_type");
        By ccExpMonth = By.Id("cc_exp_month");
        By ccExpYear = By.Id("cc_exp_year");
        By ccCvv = By.Id("cc_cvv");
        By book = By.Id("book_now");

        public void bookHotel()
        {
            driver.FindElement(firstName).SendKeys("Soman");
            driver.FindElement(lastName).SendKeys("Baqai");
            driver.FindElement(address).SendKeys("North Nazimabad");
            driver.FindElement(ccNum).SendKeys("5555555555554444");

            SelectElement selectCcType = new SelectElement(driver.FindElement(ccType));
            selectCcType.SelectByText("VISA");

            SelectElement selectCcExpMonth = new SelectElement(driver.FindElement(ccExpMonth));
            selectCcExpMonth.SelectByText("April");

            SelectElement selectCcExpYear = new SelectElement(driver.FindElement(ccExpYear));
            selectCcExpYear.SelectByText("2022");

            driver.FindElement(ccCvv).SendKeys("123");

            driver.FindElement(book).Click();

            Thread.Sleep(5000);
        }
    }
}
