﻿using System;
using OpenQA.Selenium.Chrome;
namespace adactin_pom
{
    public class BaseClass
    {
        public static ChromeDriver driver;
        private String url = "https://adactinhotelapp.com/";
        public BaseClass()
        {
        }
        
        public void Initialization()
        {
            // ChromeOptions options = new ChromeOptions();
            //options.AddArguments("--start-maximized");
            //options.AddArguments("-incognito");
            //options.AddArguments("headless");

            driver = new ChromeDriver();
        }

        public void OpenBrowser()
        {

            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl(url);
        }

        public void Dispose()
        {
            //driver = new ChromeDriver();
            driver.Dispose();
            //driver.D
        }
    }
}
