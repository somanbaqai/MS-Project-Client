﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
namespace adactin_pom
{
    [TestFixture]
    public class SearchHotelTest
    {
        LoginHelper loginHelper = new LoginHelper();
        SearchHelper searchHelper = new SearchHelper();

        [SetUp]
        public void TestInit()
        {
            searchHelper.Initialization();
        }

        [Test]
        public void SearchhotelSuccessfully()
        {
            searchHelper.OpenBrowser();
            loginHelper.Login("kamran90", "Karachi123");
            searchHelper.Search();
            string msg = BaseClass.driver.FindElement(By.CssSelector("table.content:nth-child(2) form:nth-child(1) table.login tbody:nth-child(1) tr:nth-child(1) > td.login_title")).Text;
            Assert.IsTrue(msg.ToLower().Contains("select hotel"));
        }
        [TearDown]
        public void TestDispose()
        {
            searchHelper.Dispose();
        }
    }
}
