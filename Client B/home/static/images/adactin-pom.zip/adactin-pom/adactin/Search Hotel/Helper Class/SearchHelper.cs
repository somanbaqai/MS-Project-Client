﻿using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace adactin_pom
{
    public class SearchHelper : BaseClass
    {
        By location = By.Id("location");
        By hotel = By.Id("hotels");
        By roomType = By.Id("room_type");
        By roomNo = By.Id("room_nos");
        By checkInDate = By.Id("datepick_in");
        By checkOutDate = By.Id("datepick_out");
        By adultPerRoom = By.Id("adult_room");
        By childPerRoom = By.Id("child_room");
        By searchSubmit = By.Id("Submit");

        //string selectedLocation, string selectedHotel,
        //                   string selectedNoOfRooms, string selectedCheckInDate
        //                   string selectedCheckoutDate
        public void Search()
        {
            SelectElement selectLocation = new SelectElement(driver.FindElement(location));
            selectLocation.SelectByText("London");

            SelectElement selectHotel = new SelectElement(driver.FindElement(hotel));
            selectHotel.SelectByText("Hotel Creek");

            SelectElement selectNoOfRooms = new SelectElement(driver.FindElement(roomNo));
            selectNoOfRooms.SelectByText("2 - Two");

            driver.FindElement(checkInDate).SendKeys("12/12/2022");
            driver.FindElement(checkOutDate).SendKeys("15/12/2022");

            SelectElement selectAdultsPerRoom = new SelectElement(driver.FindElement(adultPerRoom));
            selectAdultsPerRoom.SelectByText("1 - One");
            //Thread.Sleep(5000);

            driver.FindElement(searchSubmit).Click();

            //Thread.Sleep(5000);



        }

    }

    
}
