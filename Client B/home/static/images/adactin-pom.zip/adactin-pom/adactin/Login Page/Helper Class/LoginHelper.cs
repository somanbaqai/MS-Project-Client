﻿using System;
using OpenQA.Selenium;

namespace adactin_pom
{
    public class LoginHelper : BaseClass
    {
        By username = By.Id("username");
        By password = By.Id("password");
        By login = By.Id("login");

        public void Login(string user, string passcode)
        {

            driver.FindElement(username).SendKeys(user);
            driver.FindElement(password).SendKeys(passcode);
            driver.FindElement(login).Click();
        }
    }
}
