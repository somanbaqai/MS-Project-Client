﻿using System;
//using NuGet.Frameworks;
using NUnit.Framework;
using OpenQA.Selenium;

namespace adactin_pom
{
    [TestFixture]
    public class LoginTest
    {
        LoginHelper loginHelper = new LoginHelper();

        [SetUp]
        public void TestInit()
        {
            loginHelper.Initialization();
        }

        [Test]
        public void LoginSuccessful()
        {
            loginHelper.OpenBrowser();
            loginHelper.Login("kamran90", "Karachi123");
            string msg = BaseClass.driver.FindElement(By.XPath("//td[contains(text(),'Welcome to Adactin Group of Hotels')]")).Text;
            Assert.IsTrue(msg.Contains("Welcome"));
        }

        [Test]
        public void Loginfailure()
        {
            loginHelper.OpenBrowser();
            loginHelper.Login("kamran90", "Karachi1234");
            string msg = BaseClass.driver.FindElement(By.XPath("//body[1]/table[2]/tbody[1]/tr[1]/td[2]/form[1]/table[1]/tbody[1]/tr[5]/td[2]/div[1]/b[1]")).Text;
            Assert.IsTrue(msg.ToLower().Contains("invalid"));
        }

        [TearDown]
        public void TestDispose()
        {
            loginHelper.Dispose();
        }
    }
}
